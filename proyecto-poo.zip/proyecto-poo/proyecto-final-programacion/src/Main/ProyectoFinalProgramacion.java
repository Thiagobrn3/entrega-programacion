package Main;

import Intro.View.Intro;
import Personas.Pasajeros.Controller.PasajeroController;
import Personas.Pasajeros.Model.Repository.PasajeroDaoImpl;
import Personas.Pasajeros.View.PasajeroABM;
import Vuelos.controller.VueloController;
import Vuelos.model.repository.VueloDaoImpl;
import Vuelos.view.VuelosABM;

public class ProyectoFinalProgramacion {

    public static void main(String[] args) {
    VueloDaoImpl VueloDaoImpl = new VueloDaoImpl();
    VueloController controller = new VueloController(VueloDaoImpl);
    PasajeroDaoImpl pasajeroDaoImpl = new PasajeroDaoImpl();
    PasajeroController pasajeroController = new PasajeroController(pasajeroDaoImpl,VueloDaoImpl);
    PasajeroABM pasajeroAbm = new PasajeroABM(pasajeroController, pasajeroDaoImpl, controller);
    VuelosABM vuelosAbm = new VuelosABM(controller);
    Intro intro = new Intro(vuelosAbm, pasajeroAbm);
    intro.setVisible(true);
    }
}
