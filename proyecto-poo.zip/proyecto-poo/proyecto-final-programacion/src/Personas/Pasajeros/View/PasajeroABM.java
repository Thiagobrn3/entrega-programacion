package Personas.Pasajeros.View;

import Personas.Pasajeros.Controller.PasajeroController;
import Personas.Pasajeros.Model.Entity.Pasajero;
import Personas.Pasajeros.Model.Repository.PasajeroDaoImpl;
import Vuelos.controller.VueloController;
import Vuelos.model.repository.VueloDaoImpl;
import Vuelos.view.VuelosABM;
import java.awt.Color;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

public class PasajeroABM extends javax.swing.JFrame {

    private PasajeroController controladora;
    private PasajeroDaoImpl pasajeroDaoImpl;
    private VueloController vueloController;


    public PasajeroABM(PasajeroController controladora, PasajeroDaoImpl pasajeroDaoImpl, VueloController vueloController) {
        initComponents();
        // Establecer el tamaño de la ventana
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize()); // Usa el tamaño de pantalla completo
        // Cambiar el color de fondo
        getContentPane().setBackground(Color.CYAN);  // Puedes elegir el color que desees
        // Establecer la acción de cerrar cuando se presiona el botón de cerrar
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.controladora = controladora;
        this.pasajeroDaoImpl = pasajeroDaoImpl;
        this.vueloController = vueloController;
        mostrarPasajeros();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablePasajero = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tablePasajero.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Apellido", "Dni", "Vuelo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Long.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablePasajero.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tablePasajero);
        if (tablePasajero.getColumnModel().getColumnCount() > 0) {
            tablePasajero.getColumnModel().getColumn(0).setResizable(false);
            tablePasajero.getColumnModel().getColumn(1).setResizable(false);
            tablePasajero.getColumnModel().getColumn(2).setResizable(false);
            tablePasajero.getColumnModel().getColumn(3).setResizable(false);
            tablePasajero.getColumnModel().getColumn(4).setResizable(false);
        }
        // Asegúrate de que "tablePasajero" sea el nombre de tu JTable
        tablePasajero.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {{
            setHorizontalAlignment(SwingConstants.LEFT);
        }});

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAgregar)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminar)))
                .addContainerGap(97, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar))
                .addGap(54, 54, 54))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        PasajeroController pasajeroController = new PasajeroController();
        VueloDaoImpl vueloDaoImpl = new VueloDaoImpl();
        PasajeroAñadir pasajeroAñadir = new PasajeroAñadir(controladora, this, vueloDaoImpl,vueloController);
        pasajeroAñadir.setVisible(true);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int[] filasSeleccionadas = tablePasajero.getSelectedRows();
        if (filasSeleccionadas.length == 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un pasajero.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (filasSeleccionadas.length > 1) {
            JOptionPane.showMessageDialog(this, "Solo puede seleccionar un pasajero.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int filaSeleccionada = tablePasajero.getSelectedRow();

        if (filaSeleccionada != -1) { // Verifica que haya una fila seleccionada
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tablePasajero.getModel();

            int idPasajero = (int) model.getValueAt(filaSeleccionada, 0);
            controladora.deletePasajero(idPasajero);

            // Eliminar la fila de la tabla
            model.removeRow(filaSeleccionada);

        }
        mostrarPasajeros();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int[] filasSeleccionadas = tablePasajero.getSelectedRows(); // Verifica las filas seleccionadas

        if (filasSeleccionadas.length == 0) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un pasajero.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (filasSeleccionadas.length > 1) {
            JOptionPane.showMessageDialog(this, "Solo puede seleccionar un pasajero.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int filaSeleccionada = tablePasajero.getSelectedRow();
        Pasajero pasajeroExistente = null;

        if (filaSeleccionada != -1) { // Verifica que haya una fila seleccionada
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tablePasajero.getModel();

            int idPasajero = (int) model.getValueAt(filaSeleccionada, 0);
            pasajeroExistente = pasajeroDaoImpl.searchPasajero(idPasajero);
        }

        PasajeroModificar pasajeroModificar = new PasajeroModificar(controladora, this, pasajeroExistente, vueloController);
        pasajeroModificar.setVisible(true);
    }//GEN-LAST:event_btnModificarActionPerformed

    public void mostrarPasajeros() {
        List<Pasajero> pasajeros = controladora.listPasajero();
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tablePasajero.getModel();

        model.setRowCount(0);//borra las filas

        // Recorrer la lista de vuelos y agregarlos al modelo de la tabla
        for (Pasajero pasajero : pasajeros) {

            model.addRow(new Object[]{
                pasajero.getPasajeroId(),
                pasajero.getNombre(),
                pasajero.getApellido(),
                pasajero.getDni(),
                pasajero.getVueloPasajero().getNroVuelo()
            });
        }

        tablePasajero.getColumnModel().getColumn(0).setMinWidth(0);
        tablePasajero.getColumnModel().getColumn(0).setMaxWidth(0);
        tablePasajero.getColumnModel().getColumn(0).setWidth(0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PasajeroABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PasajeroABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PasajeroABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PasajeroABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PasajeroController controller = new PasajeroController();
                PasajeroDaoImpl pasajeroDaoImpl = new PasajeroDaoImpl();
                VueloController vueloController = new VueloController();
                new PasajeroABM(controller, pasajeroDaoImpl, vueloController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablePasajero;
    // End of variables declaration//GEN-END:variables
}
