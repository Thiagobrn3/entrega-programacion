package Personas.Pasajeros.Controller;

import Personas.Pasajeros.Model.Entity.Pasajero;
import Personas.Pasajeros.Model.Repository.PasajeroDaoImpl;
import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDaoImpl;
import java.util.List;

public class PasajeroController {
    private PasajeroDaoImpl pasajeroDaoImpl;
    
    private VueloDaoImpl vueloDao;
    
    public PasajeroController(PasajeroDaoImpl pasajeroDaoImpl, VueloDaoImpl vueloDaoImpl){
        this.pasajeroDaoImpl = pasajeroDaoImpl;
        this.vueloDao = vueloDaoImpl;
    }

    public PasajeroController() {
        this.pasajeroDaoImpl = new PasajeroDaoImpl();
        this.vueloDao = new VueloDaoImpl();
    }
    
    public void addPasajero(String nombre, String apellido, long dni, Vuelo vueloPasajero){
        Pasajero pasajero = new Pasajero(nombre, apellido, dni, vueloPasajero);
        pasajeroDaoImpl.createPasajero(pasajero);
    }
    
    public void deletePasajero(int id){
        pasajeroDaoImpl.deletePasajero(id);
    }
    
    public void updatePasajero(int idPasajero,String nombre, String apellido, String dni, String nroVuelo){
        Pasajero pasajeroExistente = pasajeroDaoImpl.searchPasajero(idPasajero);
        pasajeroExistente.setNombre(nombre);
        pasajeroExistente.setApellido(apellido);
        Long dniLong = Long.parseLong(dni);
        pasajeroExistente.setDni(dniLong);
        
        Vuelo vueloPasajero = vueloDao.searchVueloNro(nroVuelo);
        pasajeroDaoImpl.updatePasajero(pasajeroExistente, idPasajero);
    }
    
    public List<Pasajero> listPasajero() {
        List<Pasajero> listaPasajeros = pasajeroDaoImpl.readAll();
        return listaPasajeros;
    }
}
