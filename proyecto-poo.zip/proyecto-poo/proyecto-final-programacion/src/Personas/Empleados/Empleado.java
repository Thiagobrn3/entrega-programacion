package Personas.Empleados;

import Aviones.Model.Entity.Avion;
import Vuelos.model.entity.Vuelo;
import java.util.Objects;

public class Empleado extends Personas.Persona{
    protected String puestoDeTrabajo;
    protected Vuelo vuelo;
    protected Avion avion;

    public Empleado(String puestoDeTrabajo, Vuelo vuelo, Avion avion, String nombre, String apellido, long dni) {
        super(nombre, apellido, dni);
        this.puestoDeTrabajo = puestoDeTrabajo;
        this.vuelo = vuelo;
        this.avion = avion;
    }

    public Empleado(String puestoDeTrabajo, Vuelo vuelo, Avion avion) {
        this.puestoDeTrabajo = puestoDeTrabajo;
        this.vuelo = vuelo;
        this.avion = avion;
    }

    public String getPuestoDeTrabajo() {
        return puestoDeTrabajo;
    }

    public void setPuestoDeTrabajo(String puestoDeTrabajo) {
        this.puestoDeTrabajo = puestoDeTrabajo;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Empleado{" + "puestoDeTrabajo=" + puestoDeTrabajo + ", vuelo=" + vuelo + ", avion=" + avion + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + Objects.hashCode(this.puestoDeTrabajo);
        hash = 43 * hash + Objects.hashCode(this.vuelo);
        hash = 43 * hash + Objects.hashCode(this.avion);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empleado other = (Empleado) obj;
        if (!Objects.equals(this.puestoDeTrabajo, other.puestoDeTrabajo)) {
            return false;
        }
        if (!Objects.equals(this.vuelo, other.vuelo)) {
            return false;
        }
        return Objects.equals(this.avion, other.avion);
    }
    
    
}
