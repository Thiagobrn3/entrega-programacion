package Vuelos.controller;

import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDao;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class VueloController {

    private VueloDao vueloDao;

    public VueloController(VueloDao vueloDao) {
        this.vueloDao = vueloDao;
    }

    public VueloController() {
    }
    
    

    public void addVuelo(String nroVuelo, String aeroSalida, String aeroLlegada, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo nuevoVuelo = new Vuelo(nroVuelo, horaSalida, horaLlegada, fechaSalida, fechaLlegada, aeroSalida, aeroLlegada);
        vueloDao.createVuelo(nuevoVuelo);
    }

    public void removeVuelo(int idVuelo) {
        vueloDao.deleteVuelo(idVuelo);
    }
    
    public Vuelo searchVueloNroVuelo(String nroVuelo){
        return vueloDao.searchVueloNro(nroVuelo);
    }
    
    public Vuelo searchVuelo(int idVuelo){
        return vueloDao.searchVuelo(idVuelo);
    }

    public void updateVuelo(int idVuelo, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo vueloExistente = vueloDao.searchVuelo(idVuelo);
        if (vueloExistente != null) {
            vueloExistente.setHoraSalida(horaSalida);
            vueloExistente.setHoraLlegada(horaLlegada);
            vueloExistente.setFechaSalida(fechaSalida);
            vueloExistente.setFechaLlegada(fechaLlegada);
            vueloDao.updateVuelo(vueloExistente, idVuelo);
        }
    }

    public List<Vuelo> listVuelos() {
        return vueloDao.readAll();
    }
}
