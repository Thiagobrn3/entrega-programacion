package Vuelos.model.repository;

import Vuelos.model.entity.Vuelo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

public class VueloDaoImpl implements VueloDao {

    private EntityManagerFactory emf;
    private EntityManager em;

    public VueloDaoImpl() {
        this.emf = Persistence.createEntityManagerFactory("proyecto-final-vuelosPU");
        this.em = emf.createEntityManager();
    }

    @Override
    public void createVuelo(Vuelo vuelo) {
        try {
            em.getTransaction().begin();
            em.persist(vuelo);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void updateVuelo(Vuelo vuelo, int id) {
        try {
            em.getTransaction().begin();
            em.merge(vuelo);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteVuelo(int idVuelo) {
        try {
        if (!em.getTransaction().isActive()) {
            em.getTransaction().begin(); // Si no está activa, iniciamos la transacción
        }
        
        Vuelo vuelo = em.find(Vuelo.class, idVuelo);
        if (vuelo != null) {
            em.remove(vuelo);
        }
        
        em.getTransaction().commit();
    } catch (Exception e) {
        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback(); // Rollback si la transacción está activa
        }
        e.printStackTrace();
    }
    }

    @Override
    public Vuelo searchVuelo(int id) {
        Vuelo vuelo = null;
        try {
            vuelo = em.find(Vuelo.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vuelo;
    }

    public Vuelo searchVueloNro(String nroVuelo) {
        try {
            return (Vuelo) em.createQuery("SELECT v FROM Vuelo v WHERE v.nroVuelo = :nroVuelo")
                    .setParameter("nroVuelo",nroVuelo)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null; // O algún manejo alternativo
        }
    }

    @Override
    public List<Vuelo> readAll() {
        List<Vuelo> vuelos = null;
        try {
            vuelos = em.createQuery("SELECT v FROM Vuelo v", Vuelo.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vuelos;
    }

    public void close() {
        if (em.isOpen()) {
            em.close();
        }
        if (emf.isOpen()) {
            emf.close();
        }
    }
}
